import { VisionBodyApp } from "@/components/VisionBodyApp";

const Index = () => {
  return <VisionBodyApp />;
};

export default Index;
